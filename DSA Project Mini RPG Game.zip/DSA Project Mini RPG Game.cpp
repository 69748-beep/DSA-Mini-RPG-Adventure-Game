#include <iostream>
#include <string>
using namespace std;

// ---- COLORS -----
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define CYAN    "\033[36m"
#define RESET   "\033[0m"

// STACK (Undo System)
struct StackNode {
    string action;
    int hp, gold;
    StackNode* next;
};

class Stack {
    StackNode* top;
public:
    Stack() { top = NULL; }

    void push(string action, int hp, int gold) {
        StackNode* node = new StackNode;
        node->action = action;
        node->hp = hp;
        node->gold = gold;
        node->next = top;
        top = node;
cout << CYAN << ">> Progress saved!" << RESET << endl;
    }
bool pop(string &action, int &hp, int &gold) {
        if (top == NULL) {
            cout << RED << "Nothing to undo!" << RESET << endl;
            return false;
        }

        StackNode* temp = top;
        action = temp->action;
        hp = temp->hp;
        gold = temp->gold;
        top = top->next;
        delete temp;

        cout << YELLOW << "Undo successful!" << RESET << endl;
        return true;
    }

    void display() {
        StackNode* curr = top;
        cout << "[History]: ";
        while (curr != NULL) {
            cout << curr->action << " -> ";
            curr = curr->next;
        }
        cout << "NULL\n";
    }
};
// QUEUE (Enemies)
struct Enemy {
    string name;
    int hp, dmg, reward;
    Enemy* next;
};

class Queue {
    Enemy* front;
    Enemy* rear;
public:
    Queue() { front = NULL; rear = NULL; }

    void enqueue(string n, int h, int d, int r) {
        Enemy* e = new Enemy;
        e->name = n;
        e->hp = h;
        e->dmg = d;
        e->reward = r;
        e->next = NULL;

        if (rear != NULL)
            rear->next = e;

        rear = e;

        if (front == NULL)
            front = e;
    }

    Enemy* getFront() { return front; }

    void dequeue() {
        if (front == NULL) return;

        Enemy* temp = front;
        front = front->next;

        if (front == NULL)
            rear = NULL;

        delete temp;
    }

    bool isEmpty() { return front == NULL; }

    void display() {
        Enemy* curr = front;
        cout << "[Enemies]: ";
        while (curr != NULL) {
            cout << curr->name << "(HP:" << curr->hp << ") ";
            curr = curr->next;
        }
        cout << endl;
    }
};
// SHOP DATA
string items[4]  = {"Elixir","Potion","Shield","Sword"};
int prices[4]   = {50,20,40,60};
int effects[4]  = {50,30,0,0};
// BINARY SEARCH
int binarySearch(string target) {
    int low = 0, high = 3;
    cout << BLUE << "[Binary Search]\n" << RESET;

    while (low <= high) {
        int mid = (low + high) / 2;
        cout << "Checking: " << items[mid] << endl;

        if (items[mid] == target)
            return mid;
        else if (items[mid] < target)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}
// LINEAR SEARCH
int linearSearch(string target) {
    cout << BLUE << "[Linear Search]\n" << RESET;

    for (int i = 0; i < 4; i++) {
        cout << "Checking: " << items[i] << endl;
        if (items[i] == target)
            return i;
    }
    return -1;
}
int main() {

    cout << CYAN << "=============================\n";
    cout << "     MINI RPG GAME\n";
    cout << "=============================\n" << RESET;

    // HERO SELECTION
    cout << "Choose Hero:\n";
    cout << "1. Knight (HP120 ATK15)\n";
    cout << "2. Archer (HP90  ATK25)\n";
    cout << "3. Mage   (HP80  ATK30)\n";

    int choice;
    cin >> choice;

    string name;
    int hp, atk, gold = 20;

    if (choice == 1) { name = "Knight"; hp = 120; atk = 15; }
    else if (choice == 2) { name = "Archer"; hp = 90; atk = 25; }
    else { name = "Mage"; hp = 80; atk = 30; }

    cout << GREEN << "You selected: " << name << RESET << endl;

    Stack history;
    Queue enemies;

    enemies.enqueue("Goblin",30,10,15);
    enemies.enqueue("Orc",50,20,25);
    enemies.enqueue("Dragon",80,30,50);

    // GAME LOOP
while (!enemies.isEmpty() && hp > 0) {

        cout << "\n--------------------------------\n";
        cout << YELLOW << name << RESET
             << " HP:" << RED << hp << RESET
             << " Gold:" << GREEN << gold << RESET
             << " ATK:" << BLUE << atk << RESET << endl;

        enemies.display();
        history.display();

        cout << "\n1.Attack  2.Shop  3.Undo\nChoice: ";
        cin >> choice;
// ATTACK
if (choice == 1) {
            Enemy* e = enemies.getFront();

            history.push("Fight", hp, gold);

            e->hp -= atk;
            cout << GREEN << "You attacked!\n" << RESET;

            if (e->hp <= 0) {
                cout << GREEN << e->name << " defeated!\n" << RESET;
                gold += e->reward;
                enemies.dequeue();
            } else {
                hp -= e->dmg;
                cout << RED << "Enemy attacked you!\n" << RESET;
            }
        }

        // SHOP
        else if (choice == 2) {

            cout << CYAN << "\n====== SHOP ======\n" << RESET;
            cout << "Item     Price   Effect\n";
            cout << "Potion   20g     +30 HP\n";
            cout << "Elixir   50g     +50 HP\n";
            cout << "Shield   40g     +10 ATK\n";
            cout << "Sword    60g     +10 ATK\n";

            cout << "Enter item: ";
            string item;
            cin >> item;

            item[0] = toupper(item[0]);
            for (int i = 1; i < item.size(); i++)
                item[i] = tolower(item[i]);

            cout << "1.Binary  2.Linear: ";
            int algo;
            cin >> algo;

            int idx;
            if (algo == 1)
                idx = binarySearch(item);
            else
                idx = linearSearch(item);

            if (idx != -1 && gold >= prices[idx]) {

                history.push("Buy", hp, gold);

                gold -= prices[idx];

                if (effects[idx] > 0) {
                    hp += effects[idx];
                    if (hp > 120) hp = 120;
                    cout << GREEN << "HP Restored!\n" << RESET;
                } else {
                    atk += 10;
                    cout << GREEN << "Attack Increased!\n" << RESET;
                }
            } else {
                cout << RED << "Invalid item or not enough gold!\n" << RESET;
            }
        }

        // UNDO
        else if (choice == 3) {
            string a;
            int h, g;

            if (history.pop(a, h, g)) {
                hp = h;
                gold = g;
            }
        }
    }

    cout << "\n=============================\n";
    if (hp > 0)
        cout << GREEN << "YOU WIN!\n" << RESET;
    else
        cout << RED << "GAME OVER!\n" << RESET;

    cout << "Final Gold: " << gold << endl;

    cout << "\nComplexity:\n";
    cout << "Stack: O(1)\nQueue: O(1)\nBinary: O(log n)\nLinear: O(n)\n";

    return 0;
}
